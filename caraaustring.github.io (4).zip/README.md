# Publish at caraaustring.github.io
1. Signed in as caraaustring on github.com, click + (top right) > New repository.
2. Name it exactly: caraaustring.github.io. Set it Public. Click Create repository.
3. Click "uploading an existing file", drag in everything from this folder (index.html, resume.pdf, images folder), then Commit changes.
4. Go to Settings > Pages. Under Build and deployment, choose "Deploy from a branch", branch main, folder / (root), then Save.
5. After 1-2 minutes the site is live at https://caraaustring.github.io

## Add photos later
Open the repo > images > Add file > Upload files. Use the file names in images/README.txt. The photo replaces the illustration automatically.

## Custom domain later
Buy the domain, then in Settings > Pages enter it under Custom domain. Add the DNS records GitHub shows at your registrar.
