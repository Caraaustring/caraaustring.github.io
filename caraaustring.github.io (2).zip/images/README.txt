Put your photos in this folder using these exact file names (JPG):
hero.jpg, women-in-stem.jpg, bci-ar.jpg, w17.jpg, esp32-hunt.jpg, real-or-scam.jpg
Until a photo exists, the site shows a simple illustration in its place.
