Add 3 photos per project, as JPG files, in these folders (create the folders when uploading):
images/foundry/1.jpg, 2.jpg, 3.jpg
images/women-in-stem/1.jpg, 2.jpg, 3.jpg
images/bci-ar/1.jpg, 2.jpg, 3.jpg
images/w17/1.jpg, 2.jpg, 3.jpg
images/scavenger-hunt/1.jpg, 2.jpg, 3.jpg
images/real-or-scam/1.jpg, 2.jpg, 3.jpg
Photo 1 also appears as the hover preview on the work list. Until a photo exists, a numbered placeholder shows.
